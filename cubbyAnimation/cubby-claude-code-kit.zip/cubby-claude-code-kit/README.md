# Cubby — Claude Code kit

Everything Claude Code needs to build Cubby (minimal-and-fun, view-only on-chain portfolio tracker for React Native).

```
CLAUDE.md            ← start here (rules + read order)
docs/CUBBY_SPEC.md   ← what the app is, every screen, feature, state, build scope & milestones
docs/ANIMATIONS.md   ← every animation, timing, easing, hook
docs/TAB_BAR_ANIMATION.md  ← floating tab bar: geometry, spring, states, integration
docs/SMOOTH_ANIMATION.md   ← iOS-native "butter" guide: springs, gestures, performance, QA
docs/ASSETS.md       ← every sticker / SVG, how to use it
src/                 ← tokens, SVG art components, motion hooks, confetti, demo data (type-checks under strict TS)
assets/svg/          ← 38 Cubby SVGs (mascot, 7 stickers, 18 icons, brand, 6 charts, universe art)
assets/svg/crypto/   ← 26 real logos: ETH, USDC, BTC, SOL… tokens, 6 chains, 4 wallets
assets/tabbar-filmstrip.png ← frames of the tab bar morph
assets/crypto-preview.png ← how the real icons look in Assets/Connect (light + dark)
assets/preview.png   ← one-sheet preview of all art
```

Use: unzip into a new Expo app (or drop `CLAUDE.md`, `docs/`, `src/`, `assets/` in), then tell Claude Code:
"Read CLAUDE.md and build milestone 0 and 1 from docs/CUBBY_SPEC.md §12."

Peer deps: react-native-svg, react-native-reanimated (v3+), expo-haptics, expo-font, @expo-google-fonts/geist|geist-mono|doto.
